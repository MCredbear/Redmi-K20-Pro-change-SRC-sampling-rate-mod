A magisk mod to change Andriod's SRC sampling rate (to 44100)
Only tested on Redmi K20 Pro